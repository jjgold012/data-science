
files_to_run = ["afl.py"]

print "inserting australian football data ..."
print ""
for file in files_to_run:
    execfile(file)
print ""
print "Finished"

