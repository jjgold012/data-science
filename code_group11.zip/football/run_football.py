files_to_run = [r"nfl.py", r"data-american-football.py"]

for file in files_to_run:
    execfile(file)
