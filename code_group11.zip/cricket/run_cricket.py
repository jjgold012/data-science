files_to_run = [r"big_bash_league.py"]

print "inserting cricket data ..."
print ""

for file in files_to_run:
    execfile(file)
print ""

print "Finished"
