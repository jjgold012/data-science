

files_to_run = [r"hockey1.py"]

print "inserting hockey data ..."
print ""

for file in files_to_run:
    execfile(file)
print ""

print "Finished"